/* RESPALDO: el config.js original de tu proyecto NO se incluye en este paquete porque contiene tu URL y tu clave de Supabase.
   El original sigue intacto en tu ZIP original y en tu repositorio de GitHub. */
