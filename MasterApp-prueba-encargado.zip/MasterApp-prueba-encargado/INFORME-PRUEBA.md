# Informe · versión de prueba del perfil Encargado de proyecto

Paquete: `MasterApp-prueba-encargado.zip` · Alcance: **solo el rol Encargado de proyecto**. Los demás perfiles ejecutan el mismo código que en tu ZIP original.

## 1. Estructura del ZIP
```
MasterApp-prueba-encargado/
  LEEME-PRIMERO.txt        pasos para Windows
  INFORME-PRUEBA.md        este informe
  respaldo_original/       archivos originales (copiados de tu ZIP) de lo que se pudo modificar
  Master-App-main/         el proyecto completo con su estructura original
      index.html, css/, js/, assets/, manifest.json, service-worker.js, offline.html   ← la aplicación
      supabase/, migracion/, plantillas-csv/, docs/, scripts/, README.md               ← sin cambios (no se necesitan para abrir la interfaz)
      prueba-visual.html, js/datos-prueba-visual.js, *.bat                             ← NUEVOS: solo para revisar en tu PC
      tests/                                                                           ← pruebas automáticas
```
No incluye `node_modules`, ni claves, ni contraseñas, ni `.env`. `js/config.js` va **vacío**.

## 2. Qué archivos cambiaron y cuáles se necesitan
| Archivo | ¿Cambió? | ¿Va a la rama de GitHub? |
|---|---|---|
| `js/ui.js` | **Sí** (los 6 cambios, condicionados al rol Encargado) | **Sí** |
| `css/app.css` | **Sí** (solo se agregaron reglas nuevas del desplegable) | **Sí** |
| `service-worker.js` | **Sí** (versión de caché v1.0.5 → v1.0.6) | **Sí** |
| `package.json` | **Sí** (scripts de prueba) | Opcional |
| `tests/encargado.test.mjs`, `tests/_datos-encargado.js`, `tests/prueba-visual.test.mjs` | Nuevos | Opcional |
| `js/config.js` | **Vaciado solo en este paquete** | **NO copiar** (tu repo ya tiene sus valores) |
| `prueba-visual.html`, `js/datos-prueba-visual.js`, `ABRIR-…bat`, `INICIAR-…bat` | Nuevos (solo revisión local) | No son necesarios |
| `engine.js`, `backend.js`, `utils.js`, `catalogos.js`, `core.mjs`, `handler.mjs`, `store.mjs`, SQL | **Sin cambios** | — |

Para llevar los cambios a una rama de prueba (sin tocar `main`): `git checkout -b prueba-encargado-proyecto`, copia **solo** `js/ui.js`, `css/app.css` y `service-worker.js` (y opcionalmente `tests/` y `package.json`) sobre tu repositorio, `git add`, `git commit`, `git push -u origin prueba-encargado-proyecto`. No hagas merge hasta revisar. No hace falta volver a publicar la función de Supabase.

## 3. Cómo comprobar (en `prueba-visual.html`)
**Etiquetas:** elige *Pedro Chaperon* > **Nuevo viaje** > baja a *Horarios del viaje*: deben decir «Ingreso a planta» e «Ingreso a bodega». Luego elige *Administradora* > Nuevo viaje: ahí siguen diciendo «Ingreso a planta CP» e «Ingreso a bodega CG» (los otros perfiles no cambian).
**Botón de perfil / IDs:** elige *Nora Rivera (58 clientes)* > Inicio: el botón de arriba a la derecha muestra solo su nombre y «Encargado de proyecto».
**Rutas:** *Pedro* > Nuevo viaje > en «Ruta» haz clic, escribe «norte» y elige «Ruta Norte»: aparece el selector de Destino (la ruta tiene 2 destinos); «CP → Mayorista Escuintla» aparece **una sola vez** aunque en los datos de ejemplo está 3 veces. Al elegir una ruta se completan cliente, proyecto, origen y destino.
**Guardar y consultar:** completa los campos obligatorios (*) del formulario y guarda; el viaje aparece en **Viajes**; ábrelo, edítalo: la ruta se conserva. *(En esta página el guardado es local de ejemplo, no va a Supabase.)*

## 4. Verificación realizada (resultados reales)
| Prueba | Resultado |
|---|---|
| `npm run test:encargado` (6 cambios; Postgres con tus migraciones 001–008; **35 pantallas de los 7 demás perfiles comparadas con el HTML original: idénticas**) | **30 correctas, 0 fallidas** |
| `npm run test:visual` (la página de revisión: sin errores, datos de ejemplo, guardar un viaje con ruta y consultarlo, todos los perfiles) | **12 correctas, 0 fallidas** |
| `node tests/estatico.test.mjs` (rutas relativas, manifiesto, iconos, sin claves) | **15 correctas, 0 fallidas** (con `config.js` vacío) |
| `servidor`, `cliente-supabase`, `exportar` (pruebas anteriores del repositorio) | **Fallan, igual que antes de mis cambios** (el motor ahora exige campos nuevos, p. ej. «Placa del equipo de arrastre»); salida idéntica a la línea base |
| Navegador real (Chromium) abriendo `prueba-visual.html` con doble clic (`file://`), escritorio y teléfono | Sin errores de JavaScript; botón de perfil visible; ruta funcional |

**No verificado:** conexión con tu Supabase real (sin acceso ni credenciales); los archivos `.bat` en Windows (los escribí con el formato correcto pero no pude ejecutarlos en Windows; la alternativa es abrir `prueba-visual.html` directamente); Edge/Firefox (probé Chromium).

## 5. Para ejecutar las pruebas automáticas (opcional, requiere Node.js)
En la carpeta `Master-App-main`: `npm install` y luego `npm run test:encargado`, `npm run test:visual`, `node tests/estatico.test.mjs`.
