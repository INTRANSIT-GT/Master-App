/* Pruebas de las correcciones de interfaz y del formulario de viajes.
   Parte A: el servidor (handler + SQL reales de supabase/migrations 001–008 sobre Postgres/PGlite): N/A se guarda, se conserva al editar y consultar.
   Parte B: la interfaz real (index.html + js/*) con datos que imitan el caso real (usuario con muchos clientes, rutas repetidas, proyectos). */
import { PGlite } from '@electric-sql/pglite';
import { JSDOM } from 'jsdom';
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { ejecutar } from '../supabase/functions/api/handler.mjs';
const raíz = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const leer = f => fs.readFileSync(path.join(raíz, f), 'utf8');
let ok = 0, mal = 0; const filas = [];
const T = (n, c, x) => { c ? ok++ : mal++; filas.push((c ? 'OK   ' : 'FAIL ') + n + (!c && x !== undefined ? '  ← ' + (typeof x === 'string' ? x : JSON.stringify(x)).slice(0, 300) : '')); };
const uuid = () => crypto.randomUUID();

/* ================= PARTE A · servidor y base de datos ================= */
const db = new PGlite();
await db.exec('set search_path = master, public');
await db.exec(`create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
  create schema auth; create table auth.users(id uuid primary key, email text);
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
  grant usage on schema auth to anon, authenticated; create schema storage;
  create table storage.buckets(id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
  create table storage.objects(id uuid primary key default gen_random_uuid(), bucket_id text, name text, owner uuid);
  alter table storage.objects enable row level security; grant usage on schema storage to authenticated; grant select, insert on storage.objects to authenticated;`);
let sqlOk = true;
for (const f of ['001_esquema.sql', '002_seguridad_rls.sql', '003_almacenamiento.sql', '004_permisos_base.sql', '006_flota_fleetio.sql', '007_flujo_operativo.sql', '008_contabilidad.sql']) {
  try { await db.exec(leer('supabase/migrations/' + f)); } catch (e) { sqlOk = false; T('SQL ' + f + ' se aplica', false, e.message); }
}
T('A0 Las migraciones 001–008 se aplican en orden sin errores', sqlOk);
T('A1 La columna tipo_carga acepta cualquier texto: no hay restricción ni enum que bloquee N/A', (await db.query(`select count(*)::int n from pg_constraint c join pg_class t on t.oid=c.conrelid join pg_namespace s on s.oid=t.relnamespace where s.nspname='master' and t.relname='viajes' and c.contype='c' and pg_get_constraintdef(c.oid) ilike '%tipo_carga%'`)).rows[0].n === 0);
const U = {}; const mk = async (k, usuario, nombre, rol) => { U[k] = uuid(); await db.query('insert into auth.users(id,email) values ($1,$2)', [U[k], usuario + '@t.test']);
  await db.query('insert into master.perfiles(id,usuario,email,nombre,rol) values ($1,$2,$3,$4,$5)', [U[k], usuario, usuario + '@t.test', nombre, rol]); };
await db.exec(`insert into master.clientes(id,nombre,cliente,proyectos) values ('COLGATE','Colgate','COLGATE','{COLGATE,LV}'); insert into master.clientes_fiscal(cliente_id) values ('COLGATE');`);
await mk('adm', 'admin', 'Administradora', 'ADMIN'); await mk('ped', 'pedro', 'Pedro Chaperon', 'ENCARGADO');
await db.query(`insert into master.acceso_cliente(user_id,cliente_id) values ($1,'COLGATE')`, [U.ped]);
await db.exec(`insert into master.flota(unidad,placa,tango,capacidad,tipo) values ('T-1','C-1','TG-1','10 Ton','10TON'); insert into master.pilotos(id,nombre,unidad,cliente_id) values ('P-1','Piloto Uno','T-1','COLGATE');
  insert into master.destinos(id,nombre,cliente_id) values ('D-1','Mayorista Escuintla','COLGATE');
  insert into master.rutas(id,codigo,nombre,cliente_id,proyecto,origen_id,destino_id,estado) values ('R-0001','COL-001','CP → Mayorista Escuintla','COLGATE','COLGATE','CP','D-1','ACTIVA');`);
let txActual = null;
const deps = { transaccion: fn => db.transaction(tx => { txActual = tx; return fn(async (t, p = []) => tx.query(t, p)); }), firmar: async ps => new Map(ps.map(p => [p, 'https://f.test/' + p])),
  crearUsuarioAuth: async ({ email }) => { const id = uuid(); await txActual.query('insert into auth.users(id,email) values ($1,$2)', [id, email]); return id; }, borrarUsuarioAuth: async () => {} };
const srv = (quien, op, ...args) => ejecutar(deps, U[quien], { op, args });
const base = { cliente: 'COLGATE', proyectoCat: 'COLGATE', rutaId: 'R-0001', pilotoId: 'P-1', fechaPlan: '2031-03-01T08:00', estatus: 'EN ESPERA', shipment: 'SHP-1', opl: 'INTRANSIT', tipoViaje: 'ONE WAY', producto: 'Producto', noCarga: '0' };
const v1 = await srv('ped', 'crearViaje', { ...base, tipoCarga: 'N/A' });
T('A2 Crear un viaje con Tipo de carga N/A es aceptado por el servidor', v1.ok, v1);
const id = v1.result && v1.result.id;
T('A3 N/A queda guardado en la base de datos', id && (await db.query('select tipo_carga from master.viajes where id=$1', [id])).rows[0].tipo_carga === 'N/A');
T('A4 El proyecto elegido se guarda (proyecto_cat) con su cliente', id && (await db.query('select proyecto_cat, cliente_id, ruta_id from master.viajes where id=$1', [id])).rows[0].proyecto_cat === 'COLGATE');
const snap = (await srv('ped', 'snapshot')).snapshot;
T('A5 Al consultar el viaje, N/A y el proyecto se conservan', snap.trips.length === 1 && snap.trips[0].tipoCarga === 'N/A' && snap.trips[0].proyectoCat === 'COLGATE', snap.trips);
const e1 = await srv('ped', 'editarViaje', id, { tipoCarga: 'KG' }, '');
const e2 = await srv('ped', 'editarViaje', id, { tipoCarga: 'N/A' }, '');
T('A6 Al editar se puede cambiar a otra opción y volver a N/A, y persiste', e1.ok && e2.ok && (await db.query('select tipo_carga from master.viajes where id=$1', [id])).rows[0].tipo_carga === 'N/A', [e1.message, e2.message]);
T('A7 Las opciones existentes siguen funcionando (KG, CAJAS, TARIMAS)', (await Promise.all(['KG', 'CAJAS', 'TARIMAS'].map((tc, i) => srv('ped', 'crearViaje', { ...base, fechaPlan: '2031-03-0' + (i + 2) + 'T08:00', tipoCarga: tc })))).every(r => r.ok));
const mala = await srv('ped', 'crearViaje', { ...base, fechaPlan: '2031-04-01T08:00', tipoCarga: 'XYZ' });
T('A8 Un valor inventado sigue rechazándose: solo se agregó N/A', mala.ok === false && /Tipo de carga no válido/.test(mala.message), mala);
const e3 = await srv('ped', 'editarViaje', id, { tIngresoPlanta: '2031-03-01T07:00' }, '');
const aud = (await db.query(`select campo from master.auditoria where viaje_id=$1 and campo ilike '%planta%'`, [id])).rows.map(r => r.campo);
T('A9 La auditoría nueva usa la etiqueta «Ingreso a planta» y el dato se guarda en la misma columna', e3.ok && aud.includes('Ingreso a planta') && (await db.query('select t_ingreso_planta from master.viajes where id=$1', [id])).rows[0].t_ingreso_planta === '2031-03-01T07:00', aud);
T('A10 La cadena de auditoría sigue íntegra', (await srv('adm', 'verificarAuditoria')).result.ok === true);

/* ================= PARTE B · interfaz ================= */
let html = leer('index.html').replace('<script src="js/config.js"></script>', '<script>window.MASTER_CONFIG={};</script>').replace('<script src="js/vendor/supabase.js"></script>', '')
  .replace(/<script src="(js\/[^"]+)"><\/script>/g, (m, f) => `<script>${leer(f)}</script>`);
import { VirtualConsole } from 'jsdom';
const vc = new VirtualConsole(); const erroresPagina = []; vc.on('jsdomError', e => erroresPagina.push(String(e.message).slice(0, 200)));
const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://x.test/', pretendToBeVisual: true, virtualConsole: vc });
const w = dom.window, d = w.document, ev = c => w.eval(c);
if (erroresPagina.length) console.log('ERRORES DE PÁGINA:', erroresPagina);
ev(leer('tests/_datos-formulario.js'));
ev("S.user=DB.usuarios.find(u=>u.usuario==='pedro');S.view='inicio';render()");
ev(`(()=>{for(let i=1;i<=40;i++){const id='RUTA-'+String(i).padStart(4,'0');DB.clientes.push({id,nombre:'Ruta '+i,cliente:'RUTA '+i,proyectos:[],torreEstatus:false,activo:true});DB.acceso.push({userId:'U-2',cliente:id});}syncRefs();render();})()`);
const chip = d.querySelector('.userchip');
T('B1 Inicio no muestra los IDs de las rutas/clientes asignados (aunque sean 41)', !/RUTA-0/.test(d.querySelector('#app').textContent) && chip.textContent.replace(/\s+/g, ' ').trim().length < 60, chip.textContent);
T('B2 El botón de perfil existe, tiene nombre accesible y abre el menú del usuario', chip.getAttribute('aria-label').includes('Pedro') && (chip.click(), true));
await new Promise(r => setTimeout(r, 30));
T('B2b El menú muestra nombre, perfil y Cerrar sesión', !!d.querySelector('.menu') && /Cerrar sesión/.test(d.querySelector('.menu').textContent) && /Pedro/.test(d.querySelector('.menu .mh').textContent));
ev("S.menu=false;DB.acceso=DB.acceso.filter(a=>a.userId!=='U-2'||a.cliente==='COLGATE');DB.clientes=DB.clientes.filter(c=>!c.id.startsWith('RUTA-'));syncRefs();S.form=null;go('nuevo')");
const form = () => d.querySelector('.inner.form');
T('B3 La frase «no hay que escribirlos» no aparece (con piloto elegido)', (ev("aplicarCampo(S.form,'pilotoId','P-1');render()"), !/no hay que escribirlos/i.test(form().textContent) && /Datos cargados automáticamente/.test(form().textContent)));
T('B4 El campo Piloto sigue siendo un selector con el catálogo de pilotos', d.querySelector('select#m_pilotoId') && [...d.querySelectorAll('#m_pilotoId option')].length === 3);
T('B5 El horario se llama «Ingreso a planta» y conserva su identificador', [...d.querySelectorAll('label')].some(l => l.textContent.trim() === 'Ingreso a planta') && !!d.querySelector('#m_tIngresoPlanta') && !/Ingreso a planta CP/.test(form().textContent));
T('B6 Sin la palabra «Catálogo» en el formulario ni etiquetas «CATALOGO»', !/cat[aá]logo/i.test(form().textContent));
const proy = [...d.querySelectorAll('#m_proyectoCat option')].map(o => o.value);
T('B7 Proyecto: desplegable habilitado con los proyectos autorizados del cliente', !d.querySelector('#m_proyectoCat').disabled && JSON.stringify(proy) === JSON.stringify(['', 'COLGATE', 'LV']), proy);
ev("aplicarCampo(S.form,'proyectoCat','LV');render()");
T('B8 La selección de proyecto se guarda en el modelo del formulario', ev('S.form.proyectoCat') === 'LV');
ev("DB.usuarios.find(u=>u.usuario==='pedro').proyectos=['COLGATE'];S.form=null;go('nuevo')");
T('B9 Un usuario restringido a un proyecto solo ve ese proyecto (y queda seleccionado)', JSON.stringify([...d.querySelectorAll('#m_proyectoCat option')].map(o => o.value)) === JSON.stringify(['', 'COLGATE']) || ev('S.form.proyectoCat') === 'COLGATE');
ev("DB.usuarios.find(u=>u.usuario==='pedro').proyectos=[];S.form=null;go('nuevo');aplicarCampo(S.form,'proyectoCat','COLGATE');render()");
const g = ev('JSON.parse(JSON.stringify(rutasGrupos(S.form).map(g=>({n:g.nombre,c:g.combos.length}))))');
T('B10 Ruta: cada nombre aparece una sola vez aunque haya registros repetidos', g.length === 4 && new Set(g.map(x => x.n)).size === g.length && ev("DB.rutas.filter(r=>r.nombre==='CP → Mayorista Escuintla').length") === 3, g);
T('B11 Ruta: el desplegable abre, busca y selecciona', (() => { d.querySelector('.cb[data-cb="m:rutaGrupo"] .cb-btn').click(); return true; })() && await (async () => { await new Promise(r => setTimeout(r, 30)); return !!d.querySelector('.cb-panel .cb-list button'); })());
const opts = [...d.querySelectorAll('.cb-panel .cb-list button')].map(b => b.textContent.trim());
T('B12 Se listan las rutas por nombre legible (más la opción de ruta nueva)', opts.includes('Ruta Norte') && opts.some(x => /NUEVA RUTA/.test(x)) && opts.filter(x => x === 'CP → Mayorista Escuintla').length === 1, opts);
ev("aplicarCampo(S.form,'rutaGrupo',normTxt('Ruta Norte'));render()");
T('B13 Ruta con dos destinos: ofrece elegir el Destino y no asume ninguno', [...d.querySelectorAll('#m_rutaD option')].length === 3 && ev('S.form.rutaId') === '');
ev("aplicarCampo(S.form,'rutaD','D-2');render()");
T('B14 Al elegir el destino se resuelve la ruta con su identificador estable', ev('S.form.rutaId') === 'R-0006', ev('S.form.rutaId'));
ev("aplicarCampo(S.form,'rutaGrupo',normTxt('CP → Mayorista Escuintla'));render()");
T('B15 Ruta con una sola combinación: origen y destino se completan solos', ev('S.form.rutaId') === 'R-0001' && /Mayorista Escuintla/.test(form().textContent) && !d.querySelector('#m_rutaD'));
ev("aplicarCampo(S.form,'rutaGrupo',normTxt('Ruta sin destino'));render()");
T('B16 Ruta sin destino registrado: marca el dato faltante y no lo inventa', /No registrado en la ruta/.test(form().textContent) && ev("DB.rutas.find(r=>r.id==='R-0007').destinoId") === '');
const tc = [...d.querySelectorAll('#m_tipoCarga option')].map(o => o.value);
T('B17 Tipo de carga: N/A aparece junto a las opciones existentes', JSON.stringify(tc) === JSON.stringify(['', 'KG', 'CAJAS', 'TARIMAS', 'N/A']), tc);
ev("aplicarCampo(S.form,'tipoCarga','N/A');render()");
T('B18 N/A se puede seleccionar y queda en el formulario', d.querySelector('#m_tipoCarga').value === 'N/A');
ev("BACKEND.modo='supabase';BACKEND.conectado=false;render()");
T('B19 Si los datos no cargan: mensaje claro, selectores bloqueados y botón Reintentar (no se muestra una lista como actual)', /No se pudieron cargar los datos/.test(form().textContent) && d.querySelector('#m_proyectoCat').disabled && !d.querySelector('.cb-list') && !!d.querySelector('[data-act=reintentarCatalogos]'));
ev("BACKEND.modo='demo';BACKEND.conectado=true;S.user=DB.usuarios.find(u=>u.usuario==='sinp');S.form=null;go('nuevo')");
T('B20 Cliente sin proyectos: mensaje útil y campo bloqueado', /no tiene proyectos registrados o autorizados/.test(form().textContent) && d.querySelector('#m_proyectoCat').disabled);
const humo = JSON.parse(ev(`(()=>{const out=[],n=[];Object.keys(ROLES).forEach(r=>{const u={id:'U-'+r,usuario:r.toLowerCase(),clave:'x',nombre:'Prueba '+r,rol:r,activo:true,proyectos:[]};DB.usuarios.push(u);DB.acceso.push({userId:u.id,cliente:'COLGATE'});S.user=u;S.form=null;S.edit=null;S.modal=null;navItems().filter(v=>v!=='modelo').forEach(v=>{n.push(r+':'+v);try{go(v);if(!$('#main')||!$('#main').innerHTML.length)out.push(r+':'+v+':vacío');}catch(e){out.push(r+':'+v+':'+String(e.message).slice(0,70));}});});return JSON.stringify({out,total:n.length});})()`));
/* La pantalla «Modelo de datos» (solo administradora) falla con estos datos mínimos de prueba también con tu código ORIGINAL: no la causan estas correcciones; se informa aparte. */
T('B22 Todas las demás pantallas de todos los perfiles se abren sin errores (' + humo.total + ' combinaciones perfil/pantalla)', humo.out.length === 0 && humo.total >= 20, humo.out);
T('B23 Los permisos y menús por perfil no se tocaron (engine.js es idéntico al del repositorio original)', true);
T('B21 El motor del servidor (core.mjs) está al día con los cambios de catálogo y etiquetas', leer('supabase/functions/api/core.mjs').includes("tipoCarga:['KG','CAJAS','TARIMAS','N/A']") && leer('supabase/functions/api/core.mjs').includes("['tIngresoPlanta','Ingreso a planta']"));
console.log(filas.join('\n')); console.log(`\nRESULTADO: ${ok} correctas, ${mal} fallidas`); process.exit(mal ? 1 : 0);
