(()=>{
  DB=blankDB();
  const U=(id,usuario,nombre,rol,pr)=>({id,usuario,clave:'x',nombre,rol,activo:true,proyectos:pr||[]});
  DB.usuarios.push(U('U-1','admin','Admin Master','ADMIN'),U('U-2','pedro','Pedro Chaperon','ENCARGADO'),U('U-3','sinp','Encargado Sin Proyectos','ENCARGADO'));
  Object.keys(ROLES).forEach(r=>PERM_KEYS.forEach(p=>{DB.permisos.push({rol:r,permiso:p,habilitado:r==='ADMIN'?true:((PERM_DEFAULT[r]||[]).includes(p)&&!((PROHIBIDO[r]||[]).includes(p)))});}));
  const cl=(id,n,pr)=>({id,nombre:n,cliente:n.toUpperCase(),proyectos:pr,torreEstatus:false,activo:true,nit:'',direccionFiscal:'',correoFacturacion:'',contacto:'',telefono:'',creditoDias:'',observaciones:''});
  DB.clientes.push(cl('COLGATE','Colgate',['COLGATE','LV']),cl('SINPROY','Cliente sin proyectos',[]));
  DB.acceso.push({userId:'U-2',cliente:'COLGATE'},{userId:'U-3',cliente:'SINPROY'});
  const ruta=(id,cod,nom,o,d,pr,est)=>({id,codigo:cod,nombre:nom,cliente:'COLGATE',proyecto:pr||'COLGATE',origenId:o,destinoId:d,estado:est||'ACTIVA',origenProp:'',destinoProp:'',fuente:'CATALOGO',solicitadaPorId:'U-1',solicitadaPor:'Admin',solicitadaEn:'2026-01-01T00:00:00.000Z',validadaPor:'',validadaEn:'',rechazo:null,viajeRef:''});
  DB.rutas.push(ruta('R-0001','COL-001','CP → Mayorista Escuintla','CP','D-1'),ruta('R-0002','COL-001','CP → Mayorista Escuintla','CP','D-1'),ruta('R-0003','COL-001','CP → Mayorista Escuintla','CP','D-1'),
    ruta('R-0004','COL-002','CP → Los Andes','CP','D-2'),ruta('R-0005','COL-003','Ruta Norte','CP','D-1'),ruta('R-0006','COL-003','Ruta Norte','CP','D-2'),ruta('R-0007','COL-004','Ruta sin destino','CP',''),ruta('R-0008','COL-LV','CP → LV','CP','D-1','LV'));
  PILOTOS.length=0;PILOTOS.push({id:'P-1',nombre:'Piloto Uno',unidad:'T-1',proyecto:'COLGATE'},{id:'P-2',nombre:'Piloto Dos',unidad:'T-2',proyecto:'COLGATE'});
  FLOTA.length=0;FLOTA.push({unidad:'T-1',placa:'C-1',tango:'TG-1',capacidad:'10 Ton',tipo:'10TON'},{unidad:'T-2',placa:'C-2',tango:'TG-2',capacidad:'12 Ton',tipo:'12TON'});
  DESTINOS.length=0;DESTINOS.push({id:'D-1',nombre:'Mayorista Escuintla',proyecto:'COLGATE'},{id:'D-2',nombre:'Distribuidora Los Andes',proyecto:'COLGATE'});
  syncRefs();
})()
