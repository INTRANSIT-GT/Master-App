# Cambios · correcciones de interfaz y formulario de viajes

Base: el proyecto del ZIP `Master-App-main.zip`. No se reconstruyó nada: solo se modificó lo necesario.
**El motor de reglas (`js/engine.js`) y los permisos por perfil NO se tocaron** (el archivo es idéntico al original).

## Archivos modificados
| Archivo | Cambio |
|---|---|
| `js/ui.js` | Botón de perfil, formulario (Proyecto, Ruta, Origen/Destino), textos, desplegable con búsqueda para formularios |
| `js/utils.js` | Etiqueta visible «Ingreso a planta» (el identificador `tIngresoPlanta` no cambia) |
| `js/catalogos.js` | Se agrega `N/A` a Tipo de carga |
| `css/app.css` | Encabezado/botón de perfil que no se ensancha; panel del desplegable en teléfono |
| `supabase/functions/api/core.mjs` | **Regenerado** con `node scripts/build-core.mjs` (solo cambian 2 líneas: etiqueta y N/A). **Hay que volver a publicar la función** |
| `README.md`, `package.json` | Nota y script `test:correcciones` |
## Archivos nuevos
`tests/correcciones.test.mjs`, `tests/_datos-formulario.js` (datos de prueba), `migracion/011_diagnostico_proyectos_rutas.sql` (solo lectura), `CAMBIOS.md`.

## Qué se corrigió y por qué
1. **Inicio sin IDs / 2. botón de perfil.** Causa: el botón de perfil imprimía la lista completa de clientes asignados al usuario. Con muchos clientes se ensanchaba y desplazaba el resto del encabezado. Ahora muestra solo nombre y perfil (el título del botón lleva ambos), tiene ancho máximo con recorte y en teléfono el encabezado queda de una línea. Las asignaciones y datos no se tocaron.
3. **Piloto.** Se quitó solo «· no hay que escribirlos». Sigue siendo el selector del catálogo de pilotos con sus validaciones.
4. **Ruta.** Ahora es un desplegable con búsqueda (abre, filtra, selecciona). Muestra el nombre legible y guarda el identificador estable de la ruta. Los registros repetidos (mismo nombre) se muestran **una sola vez** sin borrar nada. Si la ruta tiene varias combinaciones de origen/destino, se ofrecen para elegir; si tiene una sola, se completan solas; si falta el origen o el destino, se marca «No registrado en la ruta» sin inventarlo. Se quitó la repetición del nombre en etiquetas. Si los datos no cargan (sin conexión o sin respuesta del servidor), se muestra un mensaje con botón **Reintentar** y los desplegables quedan bloqueados (no se muestra una lista como si estuviera actualizada).
5. **Ingreso a planta.** Solo la etiqueta visible. Columna `t_ingreso_planta` e historial intactos (los eventos de auditoría nuevos usan la etiqueta nueva; los antiguos conservan su texto).
6. **Proyecto.** Causa probable (confirmar con `migracion/011`): `migracion/010` creó los clientes con la lista de proyectos vacía, así que el desplegable no tenía opciones; además el selector ignoraba las restricciones de proyecto del perfil. Ahora usa los proyectos **autorizados** del usuario para ese cliente, guarda el valor elegido, lo conserva al editar/consultar y, si no hay proyectos o falla la consulta, muestra un mensaje claro.
7. **Tipo de carga N/A.** La lista de valores válidos vive en `js/catalogos.js` y se copia a `core.mjs` (validación del servidor). `tipo_carga` en Supabase es texto libre sin restricción: **no se requiere SQL**. Verificado: se guarda, se consulta, se edita (N/A → KG → N/A) y un valor inventado sigue rechazándose.
8. **«Catálogo».** Se quitó la etiqueta «CATALOGO» junto a los campos y se reformularon los subtítulos donde aparecía (pestaña «LISTAS», notas y ayudas). Se conservó el nombre de la sección **«Catálogos»** (menú y título), por ser una sección funcional.

## Pruebas
- `npm run test:correcciones`: **35 correctas, 0 fallidas** (servidor con tus migraciones 001–008 en Postgres/PGlite + interfaz real).
- Verificación visual en navegador real (Chromium) en escritorio y teléfono con datos que imitan el caso: 34 de 34.
- Tus pruebas existentes (`servidor`, `cliente-supabase`, `exportar`, `estatico`) **ya fallaban antes** (el motor ahora exige campos nuevos, p. ej. «Placa del equipo de arrastre», y `config.js` trae tu URL/clave real). Su salida es **idéntica** antes y después de estos cambios: no se introdujo ningún fallo nuevo.

## Pendiente / depende de configuración externa
- Publicar de nuevo la función: `supabase functions deploy api` (sin esto, el servidor rechaza N/A).
- No se pudo acceder a tu proyecto Supabase remoto: la causa de los desplegables vacíos se dedujo del código; confirma con el diagnóstico `migracion/011_diagnostico_proyectos_rutas.sql` y define los proyectos reales de cada cliente.
- Las rutas no se migraron en `010`; solo aparecen las ACTIVAS (requieren tarifa y aprobación de ambas gerencias).
- Hallazgos fuera de alcance (no modificados): `demo-seed.js` ya no arranca; las pruebas antiguas están desactualizadas; la pantalla «Modelo de datos» de la administradora falla con datos mínimos de prueba también con el código original.
- Decisión abierta: con N/A, «No. de carga» sigue siendo obligatorio para pasar a En ruta.
