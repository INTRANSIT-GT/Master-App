-- =====================================================================
-- 011 · DIAGNÓSTICO (SOLO LECTURA) · proyectos, rutas y tipo de carga
-- No modifica nada. Ejecútalo en el SQL Editor de Supabase y revisa cada resultado.
-- Sirve para confirmar por qué los desplegables de Proyecto y Ruta pueden verse vacíos o repetidos.
-- =====================================================================

-- 1) ¿Qué clientes NO tienen proyectos registrados? (sin proyectos, el desplegable Proyecto no tiene opciones)
--    La migración 010 creó los clientes con la lista de proyectos vacía.
select id, nombre, cliente, activo, cardinality(proyectos) as n_proyectos, proyectos
from master.clientes
order by cardinality(proyectos), id;

-- 2) Resumen: cuántos clientes tienen / no tienen proyectos
select count(*) filter (where cardinality(proyectos) = 0) as clientes_sin_proyectos,
       count(*) filter (where cardinality(proyectos) > 0) as clientes_con_proyectos,
       count(*) as total
from master.clientes;

-- 3) ¿Cuántos clientes tiene asignado cada usuario? (muchos clientes asignados llenaban el botón de perfil con IDs)
select p.email, p.rol, p.activo, cardinality(p.proyectos) as proyectos_restringidos, count(a.cliente_id) as clientes_asignados
from master.perfiles p left join master.acceso_cliente a on a.user_id = p.id
group by p.id order by clientes_asignados desc;

-- 4) Rutas por estado. Al crear un viaje SOLO se ofrecen las rutas en estado ACTIVA
--    (una ruta pasa a ACTIVA con tarifa + aprobación de Gerencia Comercial + aprobación de Gerencia de Transporte).
select estado, count(*) as rutas from master.rutas group by estado order by rutas desc;

-- 5) Rutas ACTIVAS por cliente y proyecto (si un proyecto no aparece aquí, su desplegable de Ruta no tiene opciones)
select cliente_id, proyecto, count(*) as rutas_activas
from master.rutas where estado = 'ACTIVA' group by 1, 2 order by 1, 2;

-- 6) Rutas repetidas (mismo cliente, proyecto, nombre, origen y destino). La pantalla ya las muestra UNA vez; aquí las ves.
--    No se borra nada: si decides depurarlas, hazlo con criterio y respaldo.
select cliente_id, proyecto, lower(btrim(nombre)) as nombre, origen_id, destino_id, count(*) as veces, array_agg(id order by id) as ids
from master.rutas group by 1, 2, 3, 4, 5 having count(*) > 1 order by veces desc;

-- 7) Rutas con el mismo nombre pero distinto origen o destino (la pantalla ofrece elegir la combinación correcta)
select cliente_id, proyecto, lower(btrim(nombre)) as nombre, count(distinct (origen_id, destino_id)) as combinaciones, array_agg(distinct origen_id) as origenes, array_agg(distinct destino_id) as destinos
from master.rutas group by 1, 2, 3 having count(distinct (origen_id, destino_id)) > 1;

-- 8) Rutas a las que les falta origen o destino (la pantalla lo marca como "No registrado en la ruta")
select id, codigo, nombre, cliente_id, proyecto, estado, origen_id, destino_id
from master.rutas where coalesce(origen_id, '') = '' or coalesce(destino_id, '') = '';

-- 9) Tipo de carga: valores usados hoy y restricciones que pudieran bloquear "N/A"
select tipo_carga, count(*) as viajes from master.viajes group by 1 order by 2 desc;
select c.conname, pg_get_constraintdef(c.oid) as definicion
from pg_constraint c join pg_class t on t.oid = c.conrelid join pg_namespace s on s.oid = t.relnamespace
where s.nspname = 'master' and t.relname = 'viajes' and pg_get_constraintdef(c.oid) ilike '%tipo_carga%';
-- (si la segunda consulta no devuelve filas, la base ya acepta N/A: no hace falta cambiar el esquema)

-- =====================================================================
-- CORRECCIÓN DE DATOS (NO se ejecuta sola) — plantilla para cuando tengas definidos tus proyectos reales:
--   update master.clientes set proyectos = array['PROYECTO 1','PROYECTO 2'] where id = 'ID_DEL_CLIENTE';
-- Los nombres de proyecto deben ser los reales de tu operación; no los inventes. Los guarda tal cual en viajes.proyecto_cat.
-- Las rutas se registran desde la aplicación (Rutas → solicitar/validar) o se cargan desde tu fuente real.
-- =====================================================================
